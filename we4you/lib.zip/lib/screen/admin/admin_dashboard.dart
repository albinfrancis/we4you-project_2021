import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:loading/indicator/ball_pulse_indicator.dart';
import 'package:loading/loading.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:we4you/modelz/orderz.dart';
import 'package:we4you/screen/admin/OrdersWidget.dart';
import 'package:we4you/screen/patientnew/CRUDModel.dart';
import 'package:we4you/screen/patientnew/MedicineModel.dart';
import 'package:we4you/utils/colors.dart';
import 'package:we4you/utils/fcm.dart';

class AdminDashboard extends StatefulWidget {
  AdminDashboard({Key key}) : super(key: key);
  static final routeName = './AdminDashboard';

  @override
  _AdminDashboardState createState() => _AdminDashboardState();
}

class _AdminDashboardState extends State<AdminDashboard> {
  List<OrderModel> orders = [];

  showAlertDialog(BuildContext context) {
    Widget cancelButton = TextButton(
      child: Text("Cancel"),
      onPressed: () {
        Navigator.of(context).pop();
      },
    );
    Widget continueButton = TextButton(
      child: Text("Confirm"),
      onPressed: () {
        removeuserInfo();
      },
    );

    AlertDialog alert = AlertDialog(
      title: Text("Alert !!!"),
      content: Text("Are you sure want to logout ?"),
      actions: [
        cancelButton,
        continueButton,
      ],
    );

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return alert;
      },
    );
  }

  removeuserInfo() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.remove('email');
    prefs.remove('username');
    prefs.remove('token');
    prefs.remove('usertype');
    Navigator.pushReplacementNamed(context, '/');
  }

  @override
  void initState() {
    super.initState();
    PushNotificationsManager();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        height: MediaQuery.of(context).size.height,
        child: Column(children: [
          SizedBox(
            height: 60,
          ),
          Padding(
              padding: EdgeInsets.symmetric(horizontal: 30),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'DashBoard,',
                    style: TextStyle(
                        color: kcText,
                        fontSize: 28,
                        fontWeight: FontWeight.bold),
                  ),
                  IconButton(
                      onPressed: () {
                        showAlertDialog(context);
                      },
                      icon: Icon(
                        Icons.logout,
                        color: kcText,
                      ))
                ],
              )),
          StreamBuilder<QuerySnapshot>(
              stream:
                  FirebaseFirestore.instance.collection('orders').snapshots(),
              builder: (context, AsyncSnapshot<QuerySnapshot> snapshot) {
                if (snapshot.hasData) {
                  orders = [];
                  snapshot.data.docs.forEach((element) {
                    OrderModel product =
                        OrderModel.fromMap(element.data(), element.id);
                    orders.add(product);
                  });

                  return Flexible(
                      child: ListView.builder(
                          shrinkWrap: true,
                          padding: const EdgeInsets.all(20),
                          itemCount: orders.length,
                          itemBuilder: (buildContext, index) =>
                              OrdersWidget(orderList: orders[index])));
                } else {
                  return Center(
                    child: Loading(
                      indicator: BallPulseIndicator(),
                      size: 40.0,
                      color: kcText,
                    ),
                  );
                }
              })
        ]),
      ),
    );
  }
}
