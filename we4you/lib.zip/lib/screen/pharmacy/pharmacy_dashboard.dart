import 'package:flutter/material.dart';
import 'package:we4you/screen/doctor/settings.dart';
import 'package:we4you/screen/pharmacy/orders.dart';
import 'package:we4you/screen/pharmacy/profile.dart';

class PharmacyDashboard extends StatefulWidget {
  PharmacyDashboard({Key key}) : super(key: key);
  static final routeName = './PharmacyDashboard';

  @override
  _PharmacyDashboardState createState() => _PharmacyDashboardState();
}

class _PharmacyDashboardState extends State<PharmacyDashboard> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFFE65100),
        title: Text("we4you"),
        elevation: .1,
      ),
      body: Center(
        child: SingleChildScrollView(
          child: ConstrainedBox(
            constraints: BoxConstraints(),
            child: Column(
              children: <Widget>[
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    new Card(
                      child: InkWell(
                        onTap: () {
                          Navigator.push(
                              context,
                              new MaterialPageRoute(
                                  builder: (BuildContext context) =>
                                      new Profile()));
                        },
                        child: new Container(
                          height: 180,
                          width: 190,
                          decoration:
                              BoxDecoration(color: const Color(0xFFE0E0E0)),
                          padding: new EdgeInsets.all(20.0),
                          child: Center(
                            child: new Column(
                              children: <Widget>[
                                Icon(
                                  Icons.account_circle_outlined,
                                  size: 80,
                                  color: Colors.orange.shade900,
                                ),
                                new Text(
                                  'Profile',
                                  style: TextStyle(
                                    fontSize: 21,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.orange.shade900,
                                  ),
                                  textAlign: TextAlign.center,
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                    new Card(
                      child: InkWell(
                        onTap: () {
                          Navigator.push(
                              context,
                              new MaterialPageRoute(
                                  builder: (BuildContext context) =>
                                      new Orders()));
                        },
                        child: new Container(
                          height: 180,
                          width: 190,
                          decoration:
                              BoxDecoration(color: const Color(0xFFE0E0E0)),
                          padding: new EdgeInsets.all(20.0),
                          child: Center(
                            child: new Column(
                              children: <Widget>[
                                Icon(
                                  Icons.book_online,
                                  size: 80,
                                  color: Colors.orange.shade900,
                                ),
                                new Text(
                                  'Orders',
                                  style: TextStyle(
                                      fontSize: 21,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.orange.shade900),
                                  textAlign: TextAlign.center,
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    new Card(
                      child: InkWell(
                        onTap: () {
                          Navigator.push(
                              context,
                              new MaterialPageRoute(
                                  builder: (BuildContext context) =>
                                      new Settings()));
                        },
                        child: new Container(
                          height: 180,
                          width: 190,
                          decoration:
                              BoxDecoration(color: const Color(0xFFE0E0E0)),
                          padding: new EdgeInsets.all(20.0),
                          child: Center(
                            child: new Column(
                              children: <Widget>[
                                Icon(
                                  Icons.settings,
                                  size: 80,
                                  color: Colors.orange.shade900,
                                ),
                                new Text(
                                  'Settings',
                                  style: TextStyle(
                                      fontSize: 21,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.orange.shade900),
                                  textAlign: TextAlign.center,
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                    new Card(
                      child: InkWell(
                        onTap: () {
                          Navigator.pushReplacementNamed(context, '/');
                        },
                        child: new Container(
                          height: 180,
                          width: 190,
                          decoration:
                              BoxDecoration(color: const Color(0xFFE0E0E0)),
                          padding: new EdgeInsets.all(20.0),
                          child: Center(
                            child: new Column(
                              children: <Widget>[
                                Icon(
                                  Icons.login_outlined,
                                  size: 80,
                                  color: Colors.orange.shade900,
                                ),
                                new Text(
                                  'Logout',
                                  style: TextStyle(
                                      fontSize: 21,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.orange.shade900),
                                  textAlign: TextAlign.center,
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
